#include <stddef.h>

#include "ParseID3.h"
#include "ID3Manager.h"
#include "Debug.h"

CID3Manager g_id3Manager;

JNIEXPORT jboolean JNICALL Java_com_zhcl_media_ID3Jni_ParseID3
  (JNIEnv *env, jclass, jstring path) {
	const char *pPath = env->GetStringUTFChars(path, NULL);
	if (pPath == NULL) {
		return false;
	}

	bool result = g_id3Manager.ParseID3(pPath);

	env->ReleaseStringUTFChars(path, pPath);

	return result;
}

JNIEXPORT jboolean JNICALL Java_com_zhcl_media_ID3Jni_ParseID3Pic
  (JNIEnv *env, jclass, jstring path, jstring savePicPath) {
	const char *pPath = env->GetStringUTFChars(path, NULL);
	if (pPath == NULL) {
		return false;
	}

	const char *pSavePicPath = env->GetStringUTFChars(savePicPath, NULL);
	if (pSavePicPath == NULL) {
		return false;
	}

	bool result = g_id3Manager.ParseID3Pic(pPath, pSavePicPath);

	env->ReleaseStringUTFChars(path, pPath);
	env->ReleaseStringUTFChars(savePicPath, pSavePicPath);

	return result;
}

JNIEXPORT jstring JNICALL Java_com_zhcl_media_ID3Jni_GetID3Title
  (JNIEnv *env, jclass) {
	return env->NewStringUTF(g_id3Manager.GetTitle());
}

JNIEXPORT jstring JNICALL Java_com_zhcl_media_ID3Jni_GetID3Artist
  (JNIEnv *env, jclass) {
	return env->NewStringUTF(g_id3Manager.GetArtist());
}

JNIEXPORT jstring JNICALL Java_com_zhcl_media_ID3Jni_GetID3Album
  (JNIEnv *env, jclass) {
	return env->NewStringUTF(g_id3Manager.GetAlbum());
}
