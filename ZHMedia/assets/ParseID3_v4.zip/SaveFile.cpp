/*
 * SaveFile.cpp
 *
 *  Created on: 2016-1-16
 *      Author: guoxs
 */

#include <stdio.h>

#include "SaveFile.h"

bool CSaveFile::SaveDataToFile(const char *pData, UINT dataLen, const char *pSavePath) {
	if ((pData == NULL) || (dataLen == 0) || (pSavePath == NULL)) {
		return false;
	}

	FILE *pFile = fopen(pSavePath, "wb");
	if (pFile == NULL) {
		return false;
	}

	const UINT oneMB = 1024 * 1024;		// 一次性最多写1M
	while (dataLen != 0) {
		if (dataLen > oneMB) {
			if (!fwrite(pData, oneMB, 1, pFile)) {
				break;
			}
			dataLen -= oneMB;
		} else {
			if (!fwrite(pData, dataLen, 1, pFile)) {
				break;
			}
			dataLen = 0;
		}
	}

	fclose(pFile);

	return (dataLen == 0);
}
