/*
 * CustomFun.cpp
 *
 *  Created on: 2016-1-12
 *      Author: guoxs
 */

#include <stdio.h>
#include <iconv.h>

#include "CustomFun.h"

bool CharsetConvert(const char *pFromCharset, const char *pToCharset,
		char *pIn, unsigned int inLen, char *pOut, unsigned int outLen) {
	iconv_t icd;

	if ((iconv_t)-1 == (icd = iconv_open(pToCharset, pFromCharset))) {
		return false;
	}

	if ((unsigned int)-1 == iconv(icd, &pIn, &inLen, &pOut, &outLen)) {
		iconv_close(icd);
		return false;
	}

	iconv_close(icd);

	return true;
}

bool WStringIsSame(const wchar_t *pWStr1, const wchar_t *pWStr2) {
	if ((pWStr1 == NULL) && (pWStr2 == NULL)) {
		return true;
	} else if ((pWStr1 == NULL) || (pWStr2 == NULL)) {
		return false;
	}

	int i = 0;
	while ((pWStr1[i] != 0) && (pWStr2[i] != 0)) {
		if (pWStr1[i] != pWStr2[i]) {
			return false;
		}
		++i;
	}

	if ((pWStr1[i] == 0) && (pWStr2[i] == 0)) {
		return true;
	}

	return false;
}
