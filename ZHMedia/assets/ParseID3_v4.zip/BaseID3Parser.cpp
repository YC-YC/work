/*
 * BaseID3Parser.cpp
 *
 *  Created on: 2016-1-16
 *      Author: guoxs
 */

#include <iostream>

#include "BaseID3Parser.h"
#include "Debug.h"


bool CBaseID3Parser::ParseID3(const char *pPath, S_ID3_INFO *pID3Info) {
	if ((pPath == NULL) || (pID3Info == NULL)) {
		return false;
	}

	FILE *pFile = fopen(pPath, "rb");
	if (pFile == NULL) {
		LOGICTRL(UART_DEBUG, "Open %s Fail!", pPath);
		return false;
	}
	
	bool result = ParseID3(pFile, pID3Info);	
	fclose(pFile);

	return result;
}

bool CBaseID3Parser::ParseID3Pic(const char *pPath, const char *pSavePicPath) {
	if ((pPath == NULL) || (pSavePicPath == NULL)) {
		return false;
	}

	FILE *pFile = fopen(pPath, "rb");
	if (pFile == NULL) {
		LOGICTRL(UART_DEBUG, "Open %s Fail!", pPath);
		return false;
	}

	bool result = ParseID3Pic(pFile, pSavePicPath);
	fclose(pFile);

	return result;
}

bool CBaseID3Parser::ParseID3(FILE *pFile, S_ID3_INFO *pID3Info) {
	bool result = HandleParseID3(pFile, pID3Info);
	if (!result && (m_pNextParser != NULL)) {
		result = m_pNextParser->ParseID3(pFile, pID3Info);
	}
	
	return result;
}
	
bool CBaseID3Parser::ParseID3Pic(FILE *pFile, const char *pSavePicPath) {
	bool result = HandleParseID3Pic(pFile, pSavePicPath);
	if (!result && (m_pNextParser != NULL)) {
		result = m_pNextParser->ParseID3Pic(pFile, pSavePicPath);
	}
	
	return result;
}
