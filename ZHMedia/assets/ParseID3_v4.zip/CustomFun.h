/*
 * CustomFun.h
 *
 *  Created on: 2016-1-12
 *      Author: guoxs
 */

#ifndef _CUSTOM_FUN_H_
#define _CUSTOM_FUN_H_

// 编码转换函数
bool CharsetConvert(const char *pFromCharset, const char *pToCharset,
		char *pIn, unsigned int inLen, char *pOut, unsigned int outLen);

bool WStringIsSame(const wchar_t *pWStr1, const wchar_t *pWStr2);

#endif /* _CUSTOM_FUN_H_ */
