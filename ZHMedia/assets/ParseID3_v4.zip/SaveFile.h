/*
 * SaveFile.h
 *
 *  Created on: 2016-1-16
 *      Author: guoxs
 */

#ifndef _SAVE_FILE_H_
#define _SAVE_FILE_H_

#include "CommDef.h"

class CSaveFile {
public:
	bool SaveDataToFile(const char *pData, UINT dataLen, const char *pSavePath);
};

#endif /* _SAVE_FILE_H_ */
